#include <iostream>
#include <Interpolators/_1D/CubicSplineInterpolator.hpp>

int main() {

  _1D::CubicSplineInterpolator<double> interp;
}
