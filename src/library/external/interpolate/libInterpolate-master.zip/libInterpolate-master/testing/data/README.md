Place data files used by unit tests in this directory. CMake will copy all contents to the working directory for the unit
tests.
