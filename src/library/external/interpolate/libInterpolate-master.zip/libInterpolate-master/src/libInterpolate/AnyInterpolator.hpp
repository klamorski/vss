
#ifndef AnyInterpolator_hpp
#define AnyInterpolator_hpp

/** @file AnyInterpolator.hpp
 * @brief
 * @author C.D. Clark III
 * @date 01/18/19
 */

#include "./Interpolators/_1D/AnyInterpolator.hpp"
#include "./Interpolators/_2D/AnyInterpolator.hpp"

#endif  // include protector
