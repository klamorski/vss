#ifndef libInterp_Utils_Indexing_hpp
#define libInterp_Utils_Indexing_hpp

/** @file Utils.hpp
 * @brief
 * @author C.D. Clark III
 * @date 12/29/16
 *
 * @todo index search functions could be improved. perhaps using the mid-point
 * method.
 */

namespace Utils {}

#endif  // include protector
